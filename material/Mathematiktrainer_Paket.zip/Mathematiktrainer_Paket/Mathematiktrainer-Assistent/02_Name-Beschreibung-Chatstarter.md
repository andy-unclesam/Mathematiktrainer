# Name, Beschreibung und Chatstarter – Mathematiktrainer-Assistent

Die Felder des Fobizz-Formulars „Assistent anlegen“, zum Kopieren.

## Name

```
Mathematiktrainer
```

## Beschreibung (Feld „Beschreibung“)

```
Aus Ihrem Arbeitsblatt, Hefteintrag oder Ihren Buchaufgaben wird ein interaktiver Mathematiktrainer für Tafel und Smartboard: Lösungswege Schritt für Schritt, die Aufgaben des Blatts per Knopf, Zufallsaufgaben in drei Stufen. Material hochladen, „Daraus bitte den Mathematiktrainer“ schreiben, den Code in den Baukasten einfügen.
```

(ca. 330 Zeichen – falls das Feld kürzer ist, den ersten Satz verwenden.)

## Chatstarter (für Lehrkräfte)

```
Daraus bitte den Mathematiktrainer. (Material als Datei, Foto oder Text anhängen)
```

```
Welche Aufgaben aus meinem Material eignen sich für einen Trainer? Bitte erst nur den Plan.
```

```
Baue einen Blitz mit Zufallsaufgaben zum Thema __ für Klasse __.
```

```
Der Baukasten meldet: __
```

## Weitere Einstellungen

| Feld | Einstellung |
|---|---|
| Vorschaubild | `03_Motivbild_Mathematiktrainer.png` hochladen |
| Plugins | **keine** – der Assistent arbeitet nur mit dem Material und seinem Skill |
| Sprachmodell | Claude Sonnet 5.5 |
| Erweitertes Denken | **aus**, falls angeboten – sonst dauern die Antworten länger und können abbrechen |
| Rolle und Instruktionen | `01_Rolle-und-Instruktionen.md` |
| Hintergrundwissen | `04_Hintergrundwissen/mathe-trainer_schnittstelle.md` und `mathe-trainer_beispiel.md` |
| Skills | `05_Skill/mathe-trainer.zip` |
| Remix erlauben | nach Wunsch – der Assistent enthält keine Schülerdaten und keine Lösungen zu Ihren Blättern |
