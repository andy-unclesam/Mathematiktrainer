# Wissensdatei: Getestetes Beispiel für den Trainer-Code

Zum Skill „mathe-trainer“. Thema „Gleichungen mit einem Platzhalter“ (Platzhalter vorne → Gegenrechnung, hinten → Unterschied): ein Vorführer mit den Aufgaben „AB Nr. 2 a)–d)“ als Knöpfe und 🎲 Zufall, ein passender Blitz mit „Im Vorführer zeigen“ und zusätzlich ein kleiner Vorführer „Brüche kürzen“, der `bruch()` und `ggT()` zeigt.

In den Baukasten eingefügt meldet er „Selbsttest ✓ 1807 Aufgaben nachgerechnet“. Genau so (nur dieser Block, rund 4 400 Zeichen) sieht deine Code-Ausgabe aus.

Worauf es ankommt:
- Eigene Hilfsfunktionen (`glLies`, `glX`, `glUmk`, `glText`, `glProbe`, `glZufall`) stehen vor `var TRAINER`.
- `pruefe()` kontrolliert unabhängig: Umkehraufgabe ausrechnen und mit der Lösung vergleichen UND die Lösung in die Gleichung einsetzen (Probe).
- `glZufall` zieht in einer Schleife mit Bedingungen und hat eine Notbremse nach 500 Versuchen.
- Die Knopf-Texte sind exakt so geschrieben, wie `parse` sie lesen kann.

```js
var THEMA = "Gleichungen lösen";
/* Gleichung a op b = c mit genau einem Platzhalter x */
function glLies(text){
  var s = String(text).replace(/[\s ]/g, "").replace(/[−–]/g, "-").replace(/X/g, "x");
  var m = s.match(/^(\d+|x)([+\-])(\d+|x)=(\d+)$/); if (!m) return null;
  var A = m[1] === "x" ? "x" : +m[1], B = m[3] === "x" ? "x" : +m[3];
  if ((A === "x") === (B === "x")) return null; return {A: A, op: m[2], B: B, C: +m[4]};
}
function glX(g){ if (g.A === "x") return g.op === "+" ? g.C - g.B : g.C + g.B; return g.op === "+" ? g.C - g.A : g.A - g.C; }
function glUmk(g){ if (g.A === "x") return [g.C, g.op === "+" ? "−" : "+", g.B]; return g.op === "+" ? [g.C, "−", g.A] : [g.A, "−", g.C]; }
function glText(g){ var w = function(q){ return q === "x" ? v("x") : nf(q); }; return w(g.A) + (g.op === "+" ? " + " : " − ") + w(g.B) + " = " + nf(g.C); }
function glProbe(g){ var x = glX(g), a = g.A === "x" ? x : g.A, b = g.B === "x" ? x : g.B; return {text: nf(a) + (g.op === "+" ? " + " : " − ") + nf(b) + " = " + nf(g.op === "+" ? a + b : a - b), ok: (g.op === "+" ? a + b : a - b) === g.C}; }
function glZufall(stufe){ var lo = stufe === "b" ? 11 : stufe === "e" ? 101 : 1001, hi = lo * 9, x, a, g, n = 0;
  do { x = zz(lo, hi); a = zz(lo, hi); n++; g = zw([{A: "x", op: "+", B: a, C: x + a}, {A: "x", op: "-", B: a, C: x}, {A: a, op: "+", B: "x", C: x + a}, {A: x + a, op: "-", B: "x", C: a}]); }
  while ((glX(g) < 1 || glX(g) === g.C) && n < 500);
  if (n >= 500) g = {A: "x", op: "+", B: 36, C: 58};            // Notbremse: feste, geprüfte Ersatzaufgabe
  return g; }
var TRAINER = [
  { id: "v1", titel: "Gleichung Schritt für Schritt", art: "vorfuehrer",
    eingabe: {platzhalter: "z. B. x − 27 = 58", beispiel: "x − 27 = 58"},
    parse: function(t){ var g = glLies(t); if (!g) return {fehler: "Bitte so eingeben: x − 27 = 58 oder 33 − x = 27"};
      if (glX(g) < 1) return {fehler: "Diese Gleichung hat keine Lösung in ℕ – das kommt später."}; return g; },
    titelVon: function(g){ return glText(g); },
    schritte: function(g){ var u = glUmk(g), x = glX(g), p = glProbe(g); return [
      {erkl: "Wo steht der Platzhalter " + v("x") + "? " + (g.A === "x" ? "<b>Vorne</b> → Gegenrechnung." : "<b>Hinten</b> → Unterschied.")},
      {erkl: g.A === "x" ? "Rechne zurück: aus " + (g.op === "+" ? "+ wird −" : "− wird +") + "." : "x ist der Unterschied: größere minus kleinere Zahl.", zeile: v("x") + " = " + nf(u[0]) + " " + u[1] + " " + nf(u[2])},
      {erkl: "Ausrechnen.", zeile: v("x") + " = " + erg(nf(x))},
      {erkl: "Probe: Lösung einsetzen.", zeile: "Probe: " + p.text + (p.ok ? " ✓" : " ✗")}]; },
    presets: [{gruppe: "AB Nr. 2", label: "a)", text: "x + 57 = 83"}, {gruppe: "AB Nr. 2", label: "b)", text: "x − 46 = 79"}, {gruppe: "AB Nr. 2", label: "c)", text: "128 + x = 300"}, {gruppe: "AB Nr. 2", label: "d)", text: "415 − x = 238"}],
    zufall: function(stufe){ var g = glZufall(stufe); return glText(g).replace(/<[^>]+>/g, "").replace(/ /g, ""); },
    pruefe: function(g){ var u = glUmk(g), r = u[1] === "+" ? u[0] + u[2] : u[0] - u[2]; return r === glX(g) && glProbe(g).ok && glX(g) >= 1; } },
  { id: "b1", titel: "Gleichungs-Blitz", art: "blitz",
    erzeuge: function(stufe){ var g = glZufall(stufe), u = glUmk(g), x = glX(g);
      return {frage: "Löse: " + glText(g), loesung: v("x") + " = " + nf(u[0]) + " " + u[1] + " " + nf(u[2]) + " = " + erg(nf(x)) + "<br>Probe: " + glProbe(g).text + " ✓",
        daten: g, vorfuehren: {trainer: "v1", text: glText(g).replace(/<[^>]+>/g, "").replace(/ /g, "")}}; },
    pruefe: function(g){ return glProbe(g).ok && glX(g) >= 1; } },
  { id: "v2", titel: "Brüche kürzen", art: "vorfuehrer",
    eingabe: {platzhalter: "z. B. 18/24", beispiel: "18/24"},
    parse: function(t){ var m = String(t).replace(/\s/g, "").match(/^(\d+)\/(\d+)$/); if (!m || +m[2] === 0) return {fehler: "Bitte so eingeben: 18/24"}; return {z: +m[1], n: +m[2]}; },
    titelVon: function(b){ return "Kürze " + bruch(b.z, b.n) + " vollständig."; },
    schritte: function(b){ var g = ggT(b.z, b.n); return [
      {erkl: "Suche den größten gemeinsamen Teiler von " + b.z + " und " + b.n + "."},
      {erkl: "ggT(" + b.z + ", " + b.n + ") = " + g, zeile: "ggT = " + g},
      {erkl: "Zähler und Nenner durch " + g + " teilen.", zeile: bruch(b.z, b.n) + " = " + bruch(b.z / g, b.n / g)}]; },
    presets: [{gruppe: "Material", label: "a)", text: "18/24"}],
    pruefe: function(b){ var g = ggT(b.z, b.n); return ggT(b.z / g, b.n / g) === 1 && (b.z / g) * b.n === b.z * (b.n / g); } }
];
```
