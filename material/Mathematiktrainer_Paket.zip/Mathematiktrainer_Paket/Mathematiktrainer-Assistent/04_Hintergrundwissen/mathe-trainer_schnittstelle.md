# Wissensdatei: Schnittstelle für Vorführer und Blitz

Zum Skill „mathe-trainer“. Beschreibt den Trainer-Code, den du ausgibst. Die Lehrkraft fügt ihn in „mathematiktrainer-baukasten.html“ ein; Aussehen, Kopfleiste, Bedienung, Selbsttest und Speichern erledigt der Baukasten.

## Aufbau des Trainer-Codes

```js
var THEMA = "Gleichungen lösen";        // erscheint im Titel: „Mathematiktrainer – Gleichungen lösen“
/* eigene Hilfsfunktionen für das Thema (lesen, rechnen, darstellen) */
var TRAINER = [ { …Vorführer… }, { …Blitz… } ];
```

### Vorführer
```js
{ id: "v1",                       // eindeutig, nur Buchstaben/Ziffern
  titel: "Gleichung Schritt für Schritt",
  art: "vorfuehrer",
  eingabe: {platzhalter: "z. B. x − 27 = 58", beispiel: "x − 27 = 58"},   // beispiel wird beim Laden gezeigt
  parse: function(text){ … return aufgabe; }                 // Objekt mit den Daten der Aufgabe
                                                            // ODER {fehler: "Bitte so eingeben: …"}
                                                            // optional aufgabe.hinweis = "…" (erscheint unter der Aufgabe)
  titelVon: function(aufgabe){ return "HTML der Aufgabe"; },
  schritte: function(aufgabe){ return [ {erkl: "…", zeile: "…", bild: "…"}, … ]; },
  presets: [{gruppe: "AB Nr. 2", label: "a)", text: "x + 57 = 83"}, …],
  zufall: function(stufe){ return "Aufgabentext, den parse lesen kann"; },   // optional
  pruefe: function(aufgabe){ return true/false; } }          // unabhängige Kontrolle
```
Ein Schritt (Objekt in schritte):
- **erkl** (Pflicht): kurzer Erklärsatz in Schülersprache – erscheint rechts als nummerierte Liste.
- **zeile** (optional): eine Zeile, wie sie ins Heft kommt – erscheint links unter der Aufgabe und bleibt stehen.
- **bild** (optional): SVG oder HTML, das links oben angezeigt wird; ein späterer Schritt mit bild ersetzt das frühere Bild (so entsteht eine Animation, z. B. Bögen am Rechenstrich nacheinander).
Der erste Schritt ist meist „Lies …/Was ist gegeben?“ ohne zeile. Der letzte Schritt ist – wo sinnvoll – die Probe bzw. Kontrolle.

### Blitz
```js
{ id: "b1", titel: "Gleichungs-Blitz", art: "blitz",
  erzeuge: function(stufe){ return {
      frage: "Löse: …",                         // HTML, mit Operator
      loesung: "… = " + erg(…),                 // HTML, vollständige Kurzlösung
      daten: {…},                               // alles, was pruefe braucht
      vorfuehren: {trainer: "v1", text: "…"}    // optional: Knopf „Im Vorführer zeigen ▸“
  }; },
  pruefe: function(daten){ return true/false; } }
```

### Hilfsfunktionen im Baukasten (benutzen, nicht neu schreiben)
- `zz(a, b)` – ganze Zufallszahl von a bis b
- `zw(liste)` – zufälliges Element; `mischen(liste)` – neue, gemischte Liste
- `ggT(a, b)` – größter gemeinsamer Teiler
- `nf(zahl)` – Anzeige mit −, schmalem Tausender-Leerzeichen und Dezimalkomma
- `bruch(z, n)` – Bruch mit waagrechtem Bruchstrich
- `v("x")` – Variable kursiv; `erg(text)` – Endergebnis doppelt unterstrichen
- `zahl(text)` – liest eine Eingabe (− oder -, Komma) als Zahl, sonst null

### CSS-Klassen im Baukasten
- `hl` Markierung (Textmarker), `v` Variable, `erg` Endergebnis, `bruch` Bruch – für eigenes HTML in erkl, zeile, bild, frage und loesung.

### Tastatur und Kopfleiste (im Baukasten schon fertig)
- → oder Leertaste: nächster Schritt bzw. Aufdecken/neue Aufgabe; ←: zurück; A: alles zeigen; N: neue Zufallsaufgabe
- 1–4: Reiter wechseln; T: Tafelmodus (dunkel, kontrastreich); F: Vollbild; + und −: Schriftgröße

## Typische Vorführer-Schritte (Orientierung)
- **Gleichung lösen:** Wo steht die Variable? → Umkehraufgabe aufschreiben → ausrechnen → Probe.
- **Term berechnen:** Was wird zuerst gerechnet (Klammern, Punkt vor Strich)? → je Rechenschritt eine zeile → Ergebnis.
- **Text → Term:** Verb im Imperativ → Art des Terms → Signalwort (zu/zur, von) → Klammern füllen → Wert berechnen (hervorheben mit `<span class="hl">…</span>`).
- **Bruch kürzen/erweitern:** ggT bzw. Erweiterungszahl bestimmen → Zähler und Nenner teilen bzw. multiplizieren → Ergebnis.
- **Schriftliches Rechnen:** Stelle für Stelle von rechts; ein Schritt je Stelle mit Übertrag; Darstellung als kleine HTML-Tabelle im bild-Feld, die mit jedem Schritt eine Ziffer mehr zeigt.

### Muster: einfaches SVG-Bild (Zahlenstrahl)
```js
function strahl(von, bis, markiert){   // Zahlenstrahl mit markierten Zahlen
  var W = 600, x = function(z){ return 30 + (z - von) / (bis - von) * (W - 60); }, s = '<svg viewBox="0 0 ' + W + ' 70" width="100%" style="max-width:36rem">';
  s += '<line x1="20" y1="35" x2="' + (W - 15) + '" y2="35" stroke="currentColor" stroke-width="2"/>';
  for (var z = von; z <= bis; z++) s += '<line x1="' + x(z) + '" y1="29" x2="' + x(z) + '" y2="41" stroke="currentColor"/>' + '<text x="' + x(z) + '" y="62" text-anchor="middle" font-size="14" fill="currentColor">' + nf(z) + '</text>';
  (markiert || []).forEach(function(z){ s += '<circle cx="' + x(z) + '" cy="35" r="6" fill="#1d4ed8"/>'; });
  return s + '</svg>'; }
```
In einem Schritt: `{erkl: "Markiere 3 und 7.", bild: strahl(0, 10, [3, 7])}`.
