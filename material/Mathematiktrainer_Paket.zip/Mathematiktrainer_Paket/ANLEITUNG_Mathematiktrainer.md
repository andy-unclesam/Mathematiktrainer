# Der Mathematiktrainer – Anleitung

*Stand: 13. November 2026 · Andreas Hemmeter · Begleitmaterial zum Beitrag https://andreas-hemmeter.de/Mathematiktrainer/*

Der Mathematiktrainer ist eine HTML-Datei für Tafel und Smartboard. Sie führt Rechenwege Schritt für Schritt vor, lädt die Aufgaben Ihres Arbeitsblatts per Knopf und erzeugt Zufallsaufgaben in drei Stufen. Den Trainer zu Ihrem Material schreibt ein **KI-Assistent in Fobizz**. Er liefert nur einen kurzen Code-Block. Den fügen Sie in den **Baukasten** ein, eine Seite im Browser. Der Baukasten macht daraus eine fertige Datei.

## Was in diesem Paket liegt

```
Mathematiktrainer_Paket/
├─ ANLEITUNG_Mathematiktrainer.md              ← diese Datei
├─ mathematiktrainer-baukasten.html            der Baukasten (läuft offline im Browser; online: andreas-hemmeter.de/Mathematiktrainer/baukasten/)
├─ Beispiel_Mathematiktrainer_Gleichungen.html fertiger Beispiel-Trainer zum Ausprobieren
└─ Mathematiktrainer-Assistent/
   ├─ 01_Rolle-und-Instruktionen.md            Text für „Rolle und Instruktionen“
   ├─ 02_Name-Beschreibung-Chatstarter.md      Name, Beschreibung, vier Chatstarter, Einstellungen
   ├─ 03_Motivbild_Mathematiktrainer.png (+ .svg)  Vorschaubild 1024 × 1024
   ├─ 04_Hintergrundwissen/
   │  ├─ mathe-trainer_schnittstelle.md         Aufbau von Vorführer und Blitz, Hilfsfunktionen
   │  └─ mathe-trainer_beispiel.md              getesteter Beispiel-Code (Gleichungen, Brüche kürzen)
   └─ 05_Skill/mathe-trainer.zip               der Skill (SKILL.md mit Entscheidungsraster, Regeln, Prüfliste; dieselben Referenzdateien)
```

## Den Assistenten einrichten

**Weg A – per Remix (empfohlen, Fobizz).** Melden Sie sich in Fobizz an und öffnen Sie die Vorlage: https://app.fobizz.com/ai/chats/public_assistants/6aa1ea34-7afd-454d-8960-e6dc25832110?token=d74998fafe4035edf822bbc30adc2723. Klicken Sie oben rechts auf „Remix“. Die Kopie mit Instruktionen, Skill, Hintergrundwissen, Chatstartern und Bild liegt danach in Ihrer Ablage. Prüfen Sie dort das Sprachmodell (Claude Sonnet 5.5).

**Weg B – selbst anlegen** (Fobizz ohne Remix, Claude-Projekt oder ein anderes Werkzeug):

1. **Bild:** `03_Motivbild_Mathematiktrainer.png`. **Name, Beschreibung, Chatstarter:** aus `02_Name-Beschreibung-Chatstarter.md`.
2. **Rolle und Instruktionen:** den Inhalt von `01_Rolle-und-Instruktionen.md`.
3. **Sprachmodell:** Claude Sonnet 5.5 (oder das stärkste Claude-Modell Ihres Werkzeugs). **Plugins:** keine. **Erweitertes Denken:** aus, falls angeboten.
4. **Hintergrundwissen:** die beiden Dateien aus `04_Hintergrundwissen/`.
5. **Skills:** `05_Skill/mathe-trainer.zip`. Nimmt Ihr Werkzeug keine Skills an, hängen Sie den Inhalt der `SKILL.md` (im Zip) unten an die Instruktionen an.

## Einen Trainer erstellen – vier Schritte

1. **Material geben.** Im Assistenten das Arbeitsblatt, den Hefteintrag oder die Buchaufgaben hochladen (PDF, Foto oder Text). Dazu schreiben Sie „Daraus bitte den Mathematiktrainer.“
2. **Antwort lesen.** Der Assistent antwortet in drei Teilen:
   - einem kurzen **Plan**: welche Aufgaben ein Trainer werden, welche nicht und warum,
   - dem **Trainer-Code** (ein Kasten, beginnt mit `var THEMA`),
   - einer **Kontrolltabelle** mit den Ergebnissen der Knopf-Aufgaben.
   
   Vergleichen Sie die Tabelle kurz mit Ihren Lösungen.
3. **Code in den Baukasten.** Den Kasten kopieren (Kopier-Symbol), den Baukasten öffnen (online oder `mathematiktrainer-baukasten.html`), einfügen und auf „Trainer starten“ tippen.
4. **Prüfen und speichern.** Unten rechts muss „Selbsttest ✓ … Aufgaben nachgerechnet“ stehen. Klicken Sie die Knopf-Aufgaben einmal durch. Danach oben auf „💾 Als Datei speichern“. Die gespeicherte Datei startet beim Öffnen sofort, auch offline und am iPad.

Erscheint statt des Selbsttests eine Meldung, kopieren Sie sie in den Assistenten. Er liefert dann einen korrigierten Code-Block. Änderungswünsche („nur Basis und Erweitert“, „bei c) noch die Probe“) gehen genauso.

## Bedienung im Unterricht

| Taste | Wirkung |
|---|---|
| → oder Leertaste | nächster Schritt (im Blitz: aufdecken / neue Aufgabe) |
| ← | einen Schritt zurück |
| A | alles zeigen |
| N | neue Zufallsaufgabe |
| 1–4 | Reiter wechseln |
| T | Tafelmodus (dunkel, kontrastreich) |
| F | Vollbild |
| + / − | Schrift größer / kleiner |

## Datenschutz

Der Trainer enthält nur Aufgaben und Rechenwege, keine Schülerdaten. Der Baukasten und die gespeicherten Dateien laufen vollständig im Browser und übertragen nichts. Im Fobizz-Assistenten arbeiten nur Sie als Lehrkraft. Laden Sie dort kein Material mit Namen oder Noten von Kindern hoch.

## Grenzen

Der Selbsttest rechnet jede Knopf-Aufgabe und je Stufe 300 Zufallsaufgaben mit einer unabhängigen Probe nach. Er prüft aber nur Ergebnisse, nicht die Didaktik. Ob die Schritte so erklärt sind, wie Sie es im Unterricht machen, sehen Sie beim einmaligen Durchklicken. Offene Aufgaben (Begründen, Konstruieren, Sachaufgaben mit eigenem Kontext) setzt der Assistent bewusst nicht um und sagt das im Plan. Bricht eine Antwort ab, bitten Sie um höchstens zwei Trainer. Hilft das nicht, schalten Sie „Erweitertes Denken“ aus.

## Lizenz

Texte und Anleitung: CC BY-SA 4.0 – Andreas Hemmeter. Code von Baukasten und Beispiel: MIT. Die Fobizz-Vorlage steht unter CC BY. Erstellt mit Unterstützung von Claude Cowork.
